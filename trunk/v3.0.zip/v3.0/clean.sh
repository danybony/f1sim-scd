gnat clean -P f1sim_circuit.gpr
gnat clean -P f1sim_driver.gpr
gnat clean -P f1sim_startup.gpr
rm obj_logger/* -r