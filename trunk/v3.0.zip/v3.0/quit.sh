killall xterm
killall main_driver
killall po_cos_naming
